﻿using UnityEngine;
using System.Collections;

public class healthboost : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Vector2 pos = new Vector2(Random.Range(0,10), Random.Range(0,10));
		Quaternion quat = new Quaternion (Random.Range (0, 10), Random.Range (0, 10), Random.Range (0, 10), Random.Range (0, 10));
		Instantiate (this, pos, quat);
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
