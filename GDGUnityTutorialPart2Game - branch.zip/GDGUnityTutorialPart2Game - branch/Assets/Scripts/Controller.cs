﻿using UnityEngine;
using System.Collections;

public class Controller : MonoBehaviour {

	public float speed;
	public GameObject bulletPrefab;
	public GameObject muzzle;
	public float bulletSpeed;
	Vector2 lookDirection = Vector2.zero;

	
	// Update is called once per frame
	void Update () {
        Vector2 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
		lookDirection = (mousePos - (Vector2)transform.position).normalized;
		transform.right = lookDirection;
	}

	void FixedUpdate(){
		Rigidbody2D rgbody = GetComponent<Rigidbody2D> ();
		/*Vector3 velocity = Vector3.zero;

	
		
		if(Input.GetKey (KeyCode.W)) {
			velocity += Vector3.up * speed; //velocity = velocity +vector3.up*speed;
		}if (Input.GetKey (KeyCode.A)) {
			velocity += Vector3.left * speed;
		}if (Input.GetKey (KeyCode.S)) {
			velocity += Vector3.down * speed;
		}if (Input.GetKey (KeyCode.D)) {
			velocity += Vector3.right * speed;
		}

		rgbody.velocity = velocity;*/

		rgbody.AddForce (lookDirection);
	
		if (Input.GetMouseButtonDown (0)) {
			//Instantiate bullet
			GameObject newBullet = Instantiate(bulletPrefab);
			newBullet.transform.position = muzzle.transform.position;
			newBullet.transform.rotation = this.transform.rotation;
			newBullet.GetComponent<Rigidbody2D> ().velocity = (bulletSpeed+speed)*lookDirection;
		}
	}
}

